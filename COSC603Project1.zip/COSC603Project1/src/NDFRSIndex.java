import java.lang.Math;
import java.util.*;
public class NDFRSIndex {
    /**
     * @author Henry Paredes Jr
     * @version 1.0
     */
// input fields
	private double wet;			//wet bulb temperature
	private double dry;			//dry bulb temperature
	private boolean isnow;		//snow on ground indicator
	private double precip;		//rain in inches
	private double wind;		//wind speed in mph
	private double buo;			//last value of the build up index
	private int iHerb;			//current herb state of the district 1=cured, 2=transition, 3=green  
// output fields
	private double grass;		//grass spread index
	private double timber;		//timber spread index
	private double df = 0.0;	//drying factor
	private double ffm = 99.0;	//fine fuel moisture
	private double adfm = 99.0;	//adjusted (10 days) fuel moisture
	private double fload = 0.0;	//fire load rating (man-hour base)
/* values used in computing danger rating */
	private double a[] = {-0.1859, -0.859, -0.05966, -0.077373};
	private double b[] = {30.0, 19.2, 13.8, 22.5};
	private double c[] = {4.5, 12.5, 27.5};
	private double d[] = {16.0, 10.0, 7.0, 5.0, 4.0, 3.0};
/* commonly used constants */	
	public double tprecip;  	/* (precip-0.1) */
	public double dif;			/* (dry-wet)    */
	public static final double zero = 0.0;
	public static final boolean yes = true;
	public static final boolean no = false;

/**
 * Instantiates a new NDFRS index.
 *
 * @param dry the dry
 * @param wet the wet
 * @param isnow the isnow
 * @param precip the precip
 * @param wind the wind
 * @param buo the buo
 * @param iHerb the i herb
 * NDFRSIndex constructor with input fields
 */
	public NDFRSIndex(double dry, double wet, boolean isnow, double precip,
		double wind, double buo, int iHerb) {
		this.wet = wet;
		this.dry = dry;
		this.isnow = isnow;
		this.precip = precip;
		this.wind = wind;
		this.buo = buo;
		this.iHerb = iHerb;
	}
	/*
	 * this is the parameterless constructor
	 * it calls a method that interactively 
	 * prompts user for input parameters
	 */
	public NDFRSIndex(){
		setInput();
	}
	/*
     * This method computes the danger fire rating
     */
    public void isDanger(boolean isnow) {
        if(isnow) seeSnow();
        else noSnow();
    }
    
    /*
     * This method does computations if there's snow on the ground      
     */
    public void seeSnow() {
        grass = 0.0;
        timber = 0.0;
        computeBUO();
    }
    
    /*
     * Compute the build up index
     */
	public void computeBUO(){
		tprecip = precip - 0.1;
		if (tprecip >= zero) buo = getBUI();
		else 
			buo = 0.0;
	}
    
    /*
     * returns the bui computations
     */
	public double getBUI(){
		return 50.0*Math.log(1.0 - (1.0 - Math.exp(buo/50.0)))*Math.exp(-1.175*tprecip);
	}

    /*
     * This method does computations if there's no snow on the ground    
     */
    public void noSnow() {
    	dif = dry - wet;
    	computeFFM();
    	computeDF();
    	adjustFFM();
    	computeBUO();
    	computeADFM();		
		//test if fuel moistures are greater than 30%
    	If((adfm-30)>=zero){
    		chkADFM30ge0();
    	}else{		/* (adfm-30)<zero */
    		chkADFM30lt0();
    	}

    }
        
    /**
     * Compute fine fuel moisture ffm.
     */
    public void computeFFM(){
    	for (int i=0; i<2; i++){
    		if ((dif-c[i]) > zero) continue;
    	}
    	ffm = b[3]*Math.exp(a[3]*dif);

    }    

    /**
     * Compute the drying factor df.
     */
    public void computeDF(){
    	for (int i=0; i<5; i++){
    		if ((ffm - d[i]) <= zero) continue;
    		else{
    			df = 7.0;
    			return;
    		}
    	}		
    }
    
    /**
     * Adjust fine fuel moisture ffm.
     */
    public void adjustFFM(){
    	if ((ffm-1.0) < zero) ffm = 1.0;
    	else
    		ffm = ffm + (iHerb-1.0)*5.0;
		
    }

    /**
     *increase BUI by drying factor and compute ADFM
     */
    public void computeADFM(){
    	buo = buo + df;
		adfm = 0.9*ffm + 0.5 + 9.5*Math.exp(-buo/50.0);	
    }
    /*
     * 
     */
    public void chkADFM30ge0(){
    	if((ffm-30)>=zero){
    		grass = 1.0;
    		timber = 1.0;
    		return;
    	}else{	/* (ffm-30)<zero */
    		timber = 1.0;
    		if((wind-14.0)<zero){
    			grass = 0.01312*(wind+6.0)*Math.pow((33.0-ffm),1.65)-3.0;
    			if((grass-1.0)>=zero)grass = 1.0;
    		}else{	/* (wind-14.0)>=zero */
    			grass = 0.00918*(wind+14.0)*Math.pow((33.0-ffm),1.65)-3.0;
    			if((grass-99.0)>zero)grass=99.0;
    		}
    	}
    	computeFload();
    }
    /*
     * 
     */
    public void chkADFM30lt0(){
    	if((wind-14.0)<zero){
    		timber = 0.01312*(wind+6.0)*Math.pow((33.0-adfm),1.65)-3.0;
    		grass = 0.01312*(wind+6.0)*Math.pow((33.0-ffm),1.65)-3.0;
    	}else{	/* ((wind-14)>=zero) */
    		timber = 0.00918*(wind+14.0)*Math.pow((33.0-adfm),1.65)-3.0;
    		grass = 0.00918*(wind+14.0)*Math.pow((33.0-ffm),1.65)-3.0;
    		if((grass-99.0)>zero){
    			grass = 99.0;
    			if((timber-99.0)>zero)timber = 99.0;    			
    		}
    	}
    	computeFload();    		
    }

    /*
     * computing the fire load index rating is made here
     */
    public void computeFload(){
    	if(timber<=zero)return;
    	else{
    		if(buo<=zero)return;
    		else{
    			fload = 1.75*Math.log10(timber) + 0.32*Math.log10(buo) - 1.64;
    			if(fload<=zero){
    				fload = zero;
    				return;
    			}
    			else{
    				fload = Math.pow(10, fload);
    				return;
    			}
    		}
    	}
    }
    /**
     * set the input parameters interactive
     * using the parameterless constructor
     */
    public void setInput(){
    	Scanner input = new Scanner(System.in);
    	/* check for proper input */
    	try{
    		System.out.println("Enter wet bulb temperature - must be a real number");
    		this.wet = input.nextDouble();
    		System.out.println("Enter dry bulb temperature - must be a real number");
    		this.dry = input.nextDouble();
    		System.out.println("Is it snowing outside yes or no");
    		this.isnow = input.nextBoolean();
    		System.out.println("Enter precipitation - must be a real number");
    		this.precip = input.nextDouble();
    		System.out.println("Enter wind speed - must be a real number");
    		this.wind = input.nextDouble();
    		System.out.println("Enter last value of the build up index - must be a real number");
    		this.buo = input.nextDouble();
    		System.out.println("Enter current herb state of district 1=cured, 2=transition, 3=green");
    		this.iHerb = input.nextInt();
    	}catch(InputMismatchException e){
    		System.out.println("Invalid input ... try again");
    		input.close();
    	}
    }
    /**
     * displays the output parameters
     * by a call in the main program
     */
    public void displayOutput(){
    	System.out.printf("Grass spread index computed as: %f\n", grass);
    	System.out.printf("Timber spread index computed as: %f\n", timber);
    	System.out.printf("Drying factor computed as: %f\n", df);
    	System.out.printf("Fine fuel moisture computed as: %f\n", ffm);
    	System.out.printf("(10 days) adjusted fuel moisture computed as: %f\n", adfm);
    	System.out.printf("(man-hour based) fire load rating computed as: %f\n", fload);
    	System.out.printf("last value of the build up index computed as: %f\n", buo);    	
    }
}


