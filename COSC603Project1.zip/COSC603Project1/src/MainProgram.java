
public class MainProgram {

	public static void main(String[] args) {
		NDFRSIndex n = new NDFRSIndex();
		n.displayOutput();
	}

}
